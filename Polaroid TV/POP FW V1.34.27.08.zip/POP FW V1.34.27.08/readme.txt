Upgrade steps: 
If the FW version of the unit is V1.22.22.08, please follow the Option1.
Other versions please follow the Option2.

Option1:
1. Copying the files which's stored in the "V1.34" folder to SD card.
2. Power on the unit then upgrading automatically, and will trun off automatically after update complete.
3. Copying the files which's stored in the "V27.08" folder to SD card. 
4. Power on the unit then upgrading automatically, and will trun off automatically after update complete.

Option2:
1. Copying the files which are stored in the "V1.34.27.08" folder to SD card. 
2. Power on the unit then upgrading automatically, and will trun off automatically after update complete.
